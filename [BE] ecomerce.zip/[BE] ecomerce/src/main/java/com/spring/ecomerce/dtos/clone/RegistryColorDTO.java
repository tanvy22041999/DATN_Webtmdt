package com.spring.ecomerce.dtos.clone;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegistryColorDTO {
    private String nameVn;

    private String nameEn;

    private String code;
}
