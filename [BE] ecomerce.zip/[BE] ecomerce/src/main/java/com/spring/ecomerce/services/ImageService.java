package com.spring.ecomerce.services;

import com.spring.ecomerce.entities.clone.ImageEntity;

public interface ImageService {
    ImageEntity addNewImage(String url);

    ImageEntity findById(String id);
}
