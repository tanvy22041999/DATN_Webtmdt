package com.spring.ecomerce.utils;

public enum EnumRole {
    ROLE_ADMIN,
    ROLE_USER
}
