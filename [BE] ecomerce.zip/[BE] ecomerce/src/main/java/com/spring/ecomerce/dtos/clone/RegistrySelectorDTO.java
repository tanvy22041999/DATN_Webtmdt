package com.spring.ecomerce.dtos.clone;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegistrySelectorDTO {
    private String id;
    private String name;
}
