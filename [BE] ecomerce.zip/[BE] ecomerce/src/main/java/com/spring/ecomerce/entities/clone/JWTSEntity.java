package com.spring.ecomerce.entities.clone;

public class JWTSEntity {
}
